(function( undefined ) {
	window.addEventListener( 'load', function() {
		requestAnimationFrame( function() {
			let maps = document.querySelectorAll( '.fl-map iframe[data-src]' );

			for ( let i = 0; i < maps.length; i++ ) {
				maps[ i ].src = maps[ i ].dataset.src;
				delete maps[ i ].dataset.src;
			}
		} );
	} );
})();