( function( $ ) {

	$( function() {

		$( document ).trigger( 'vamtam-attempt-cube-load' );

	} );

} )( jQuery );
