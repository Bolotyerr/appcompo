<?php

include locate_template( 'templates/beaver/vamtam-heading.php' );
