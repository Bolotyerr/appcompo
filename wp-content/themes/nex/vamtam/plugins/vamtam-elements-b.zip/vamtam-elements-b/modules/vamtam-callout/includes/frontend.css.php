<?php

if ( $settings->cta_type == 'button' ) {
	FLBuilder::render_module_css( 'button', $id, VamtamCalloutModule::get_button_settings( $settings ) );
}

if ( $settings->image_type == 'icon' ) {
	FLBuilder::render_module_css('icon', $id, array(
		'align'          => '',
		'bg_color'       => $settings->icon_bg_color,
		'bg_hover_color' => $settings->icon_bg_hover_color,
		'color'          => $settings->icon_color,
		'hover_color'    => $settings->icon_hover_color,
		'icon'           => $settings->icon,
		'link'           => $settings->link,
		'link_target'    => $settings->link_target,
		'size'           => $settings->icon_size,
		'text'           => '',
	));
}

?>
<?php if ( $settings->title_size == 'custom' ) : ?>
.fl-builder-content .fl-node-<?php echo $id; ?> .fl-callout-title {
	font-size: <?php echo $settings->title_custom_size; ?>px;
	line-height: <?php echo $settings->title_custom_size; ?>px;
}
<?php endif; ?>
