<?php include locate_template( 'templates/beaver/vamtam-pricing-table.php' );
