jQuery( function() {
	jQuery( document ).trigger( 'vamtam-attempt-cube-load' );
} );
