<?php

global $content_width;

$photo    = $module->get_data();
$classes  = $module->get_classes();
$src      = $module->get_src();
$link     = $module->get_link();
$alt      = $module->get_alt();
$attrs    = $module->get_attributes();
$filetype = pathinfo( $src, PATHINFO_EXTENSION );
$rel      = ( ! empty( $link ) && '_blank' == $settings->link_target ) ? ' rel="noopener"' : '';

if ( isset( $photo->sizes ) && count( get_object_vars( $photo->sizes ) ) > 1 ) {
	if ( $settings->vamtam_sizes_attr !== 'default' ) {
		$global_settings = FLBuilderModel::get_global_settings();

		if ( $settings->vamtam_sizes_attr === 'custom' ) {
			$attrs .= ' sizes="' . esc_attr( $settings->vamtam_sizes_attr_custom ) . '"';
		} elseif ( $settings->vamtam_sizes_attr === 'beaver' ) {
			// walk up the parent tree to calculate the size of this module
			$parent_size = 100;
			$row_size    = false;
			$parent      = FLBuilderModel::get_node( $module->parent );
			while ( $parent ) {
				if ( $parent->type === 'column' ) {
					$parent_size *= (float) $parent->settings->size / 100;
				} elseif ( $parent->type === 'row' ) {
					if ( $parent->settings->width === 'full' && $parent->settings->content_width === 'full' ) {
						$row_size = 'full';
					} elseif ( $parent->settings->content_width === 'fixed' ) {
						$row_size = isset( $parent->settings->max_content_width ) && $parent->settings->max_content_width !== '' ? (int) $parent->settings->max_content_width : $content_width;
					}
				}

				$parent = FLBuilderModel::get_node( $parent->parent );
			}

			$parent_size = ceil( $parent_size );

			$row_limit = '';
			if ( $row_size !== 'full' ) {
				$row_limit = "(min-width: {$row_size}px) " . ( $row_size * $parent_size / 100 ) . "px,";
			}

			$attrs .= ' sizes="(max-width: ' . $global_settings->responsive_breakpoint . 'px) 100vw, ' . $row_limit . esc_attr( $parent_size ) . 'vw"';
		} else {
			$global_settings = FLBuilderModel::get_global_settings();

			$attrs .= ' sizes="(max-width: ' . $global_settings->responsive_breakpoint . 'px) 100vw, ' . esc_attr( $settings->vamtam_sizes_attr ) . '"';
		}
	}
}

?>
<div class="fl-photo<?php if ( ! empty( $settings->crop ) ) { echo ' fl-photo-crop-' . $settings->crop ;} ?> fl-photo-align-<?php echo $settings->align; ?>" itemscope itemtype="http://schema.org/ImageObject">
	<div class="fl-photo-content fl-photo-img-<?php echo $filetype; ?>">
		<?php if ( ! empty( $link ) ) : ?>
		<a href="<?php echo $link; ?>" target="<?php echo $settings->link_target; ?>"<?php echo $rel; ?> itemprop="url" title="<?php echo $alt ?>">
		<?php endif; ?>
		<?php if ( $settings->photo_source === 'library' && isset( $photo->width ) && isset( $photo->height ) ) : ?>
			<?php $classes .= ' vamtam-lazyload-noparent'; ?>
			<?php echo apply_filters( 'vamtam_maybe_lazyload', wp_make_content_images_responsive( '<img class="' . esc_attr( $classes ) . '" src="' . esc_attr( $src ) . '" alt="' . esc_attr( $alt ) . '" itemprop="image" ' . $attrs . '/>' ), $photo->id, array( $photo->width, $photo->height ), false ) ?>
		<?php else: ?>
			<img class="<?php echo esc_attr( $classes ) ?>" src="<?php echo esc_attr( $src ) ?>" alt="<?php echo esc_attr( $alt ) ?>" itemprop="image" <?php echo $attrs; ?> />
		<?php endif ?>
		<?php if ( ! empty( $link ) ) : ?>
		</a>
		<?php endif; ?>
		<?php if ( $photo && ! empty( $photo->caption ) && 'hover' == $settings->show_caption ) : ?>
		<div class="fl-photo-caption fl-photo-caption-hover" itemprop="caption"><?php echo $photo->caption; ?></div>
		<?php endif; ?>
	</div>
	<?php if ( $photo && ! empty( $photo->caption ) && 'below' == $settings->show_caption ) : ?>
	<div class="fl-photo-caption fl-photo-caption-below" itemprop="caption"><?php echo $photo->caption; ?></div>
	<?php endif; ?>
</div>
