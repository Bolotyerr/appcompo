<div class="fl-accordion fl-accordion-<?php echo esc_attr( $settings->label_size ); if ( $settings->collapse ) echo ' fl-accordion-collapse'; ?>">
	<?php for ( $i = 0; $i < count( $settings->items ); $i++ ) : if ( empty( $settings->items[ $i ] ) ) continue; ?>
	<div class="fl-accordion-item"<?php if ( ! empty( $settings->id ) ) echo ' id="' . sanitize_html_class( $settings->id ) . '-' . (int)$i . '"'; ?> style="border-color:<?php echo esc_attr( vamtam_el_sanitize_accent( $settings->border_color ) ) ?>">
		<div class="fl-accordion-button">
			<span class="fl-accordion-button-label"><?php echo $settings->items[ $i ]->label // xss ok ?></span>
			<i class="fl-accordion-button-icon fa-plus"></i>
		</div>
		<div class="fl-accordion-content fl-clearfix"><?php echo $settings->items[ $i ]->content // xss ok ?></div>
	</div>
	<?php endfor; ?>
</div>
